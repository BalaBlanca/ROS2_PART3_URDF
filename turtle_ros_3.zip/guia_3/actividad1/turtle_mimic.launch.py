from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        # Nodo para la primera tortuga
        Node(
            package="turtlesim",
            namespace="turtlesim1",
            executable="turtlesim_node",
            name="sim"
        ),
        # Nodo para la segunda tortuga
        Node(
            package="turtlesim",
            namespace="turtlesim2",
            executable="turtlesim_node",
            name="sim"
        ),
        # Nodo mimic que replica el movimiento
        Node(
            package="turtlesim",
            executable="mimic",
            name="mimic",
            remappings=[
                ("/input/pose", "/turtlesim1/turtle1/pose"),
                ("/output/cmd_vel", "/turtlesim2/turtle1/cmd_vel"),
            ]
        )
    ])