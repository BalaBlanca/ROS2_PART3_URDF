from launch_ros.actions import Node
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, EmitEvent, ExecuteProcess, LogInfo, RegisterEventHandler, TimerAction
from launch.conditions import IfCondition
from launch.event_handlers import OnExecutionComplete, OnProcessExit, OnProcessIO, OnProcessStart, OnShutdown
from launch.events import Shutdown
from launch.substitutions import EnvironmentVariable, FindExecutable, LaunchConfiguration, LocalSubstitution, PythonExpression

def generate_launch_description():
    # Configuración de los argumentos que vienen del main
    turtlesim_ns = LaunchConfiguration("turtlesim_ns")
    use_provided_red = LaunchConfiguration("use_provided_red")
    new_background_r = LaunchConfiguration("new_background_r")

    turtlesim_ns_launch_arg = DeclareLaunchArgument("turtlesim_ns", default_value="turtlesim1")
    use_provided_red_launch_arg = DeclareLaunchArgument("use_provided_red", default_value="False")
    new_background_r_launch_arg = DeclareLaunchArgument("new_background_r", default_value="200")

    # Definición de Nodos y Procesos
    turtlesim_node = Node(
        package="turtlesim",
        namespace=turtlesim_ns,
        executable="turtlesim_node",
        name="sim"
    )

    spawn_turtle = ExecuteProcess(
        cmd=[[
            FindExecutable(name="ros2"),
            " service call /", turtlesim_ns, "/spawn ",
            "turtlesim/srv/Spawn ",
            "\"{x: 2.0, y: 2.0, theta: 0.2}\""
        ]],
        shell=True
    )

    change_background_r = ExecuteProcess(
        cmd=[[
            FindExecutable(name="ros2"),
            " param set /", turtlesim_ns, "/sim background_r 120"
        ]],
        shell=True
    )

    # Solo cambia el fondo si pasamos "True" y el valor es "200"
    change_background_r_conditioned = ExecuteProcess(
        condition=IfCondition(
            PythonExpression([new_background_r, " == 200 and ", use_provided_red])
        ),
        cmd=[[
            FindExecutable(name="ros2"),
            " param set /", turtlesim_ns, "/sim background_r ", new_background_r
        ]],
        shell=True
    )

    # Construcción del Launch Description con Manejo de Eventos
    return LaunchDescription([
        turtlesim_ns_launch_arg,
        use_provided_red_launch_arg,
        new_background_r_launch_arg,
        turtlesim_node,
        
        # Evento: Cuando turtlesim_node inicie, lanza el proceso de spawn
        RegisterEventHandler(
            OnProcessStart(
                target_action=turtlesim_node,
                on_start=[
                    LogInfo(msg="Turtlesim started, spawning turtle"),
                    spawn_turtle
                ]
            )
        ),
        
        # Evento: Cuando termine de hacer spawn, espera 2 segundos y cambia el color
        RegisterEventHandler(
            OnExecutionComplete(
                target_action=spawn_turtle,
                on_completion=[
                    LogInfo(msg="Spawn finished"),
                    TimerAction(
                        period=2.0,
                        actions=[change_background_r_conditioned],
                    )
                ]
            )
        ),
        
        # Evento: Si se cierra la ventana de la tortuga, apaga todo el launch
        RegisterEventHandler(
            OnProcessExit(
                target_action=turtlesim_node,
                on_exit=[
                    LogInfo(msg=(EnvironmentVariable(name="USER"), " closed the turtlesim window")),
                    EmitEvent(event=Shutdown(reason="Window closed"))
                ]
            )
        )
    ])