from launch_ros.substitutions import FindPackageShare
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import PathJoinSubstitution, TextSubstitution

def generate_launch_description():
    # Definimos el color que queremos pasar como argumento
    colors = {
        "background_r": "200"
    }

    return LaunchDescription([
        # Incluimos el archivo de lanzamiento secundario
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([
                PathJoinSubstitution([
                    FindPackageShare("guia_ros2_parte3_pkg"),
                    "launch",
                    "subs_events.launch.py"
                ])
            ]),
            # Aquí le pasamos los argumentos al archivo secundario
            launch_arguments={
                "turtlesim_ns": "turtlesim2",
                "use_provided_red": "True",
                "new_background_r": TextSubstitution(text=str(colors["background_r"]))
            }.items()
        )
    ])